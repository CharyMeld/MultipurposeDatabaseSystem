
export const biodataTemplate = `
  <section v-if="biodata">
    <div class='row'>
      <div class='col-md-5 p-2'>
        <div class='candidate-image-container d-flex justify-content-center mt-2 align-center'>
          <img class='text-center align-center' :src="image" alt="profile picture" >
        </div>
      </div>
      <div class="col-md-7 p-2">
        <h4 class="mb-3">Biodata Information</h4>
        <p><strong>Surname:</strong> {{ biodata.surname }}</p>
        <p><strong>Other Name:</strong> {{ biodata.other_name }}</p>
        <p><strong>Email:</strong> {{ biodata.email }}</p>
      </div>
    </div>
  </section>
`;

export const Biodata = {
  template: biodataTemplate,
  props: ["faculty_name", "sub_speciality", "biodata", "candidate_form"],
  computed: {
    image() {
      return this.biodata?.picture_path || "/wacs_system/public/assets/images/avatar.png";
    }
  }
};
