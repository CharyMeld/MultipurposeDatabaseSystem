
export const Application = {
  template: `
    <div v-if="candidate && candidate.applications">
      <h4 class="text-center p-3">Application History</h4>
      <ul class="list-group">
        <li class="list-group-item" v-for="(app, index) in candidate.applications" :key="index">
          <strong>Center:</strong> {{ app.exam_center }},
          <strong>Date:</strong> {{ app.exam_date }},
          <strong>Time:</strong> {{ app.exam_time }},
          <strong>Venue:</strong> {{ app.exam_venue }}
        </li>
      </ul>
    </div>
  `,
  props: ['candidate']
};
