
export const Results = {
  template: `
    <div v-if="candidate && candidate.results">
      <h4 class="text-center p-3">Exam Results</h4>
      <table class="table table-bordered">
        <thead><tr><th>Exam</th><th>Score</th></tr></thead>
        <tbody>
          <tr v-for="(result, index) in candidate.results" :key="index">
            <td>{{ result.exam }}</td>
            <td>{{ result.score }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  `,
  props: ['candidate']
};
