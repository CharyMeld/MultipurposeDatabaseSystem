
import { createApp } from 'https://unpkg.com/vue@3/dist/vue.esm-browser.js';

import { Overview } from './components/Overview.js';
import { Biodata } from './components/Biodata.js';
import { Application } from './components/Application.js';
import { Documents } from './components/Documents.js';
import { Results } from './components/Results.js';
import { AppForm } from './components/AppForm.js';

const App = {
  components: {
    Overview,
    Biodata,
    Application,
    Documents,
    Results,
    AppForm,
  },
  data() {
    return {
      activeTab: 'Overview',
      candidate: candidateData || {},
      faculty_name: facultyName || '',
      sub_speciality: subSpeciality || '',
      doc_fields: docFields || [],
      full_name: fullName || '',
      formSubmitted: false,
    };
  },
  methods: {
    switchTab(tab) {
      const validTabs = ['Overview', 'Biodata', 'Application', 'Documents', 'Results'];
      this.activeTab = validTabs.includes(tab) ? tab : 'Overview';
    },
    handleFormSubmitted() {
      this.formSubmitted = true;
      setTimeout(() => (this.formSubmitted = false), 3000);
    },
    handleUpdate(...args) {
      console.log('Data updated:', args);
    },
  },
  template: `
    <div class="container mt-4">
      <ul class="nav nav-tabs">
        <li class="nav-item" v-for="tab in ['Overview', 'Biodata', 'Application', 'Documents', 'Results']" :key="tab">
          <a class="nav-link" :class="{ active: activeTab === tab }" href="#" @click.prevent="switchTab(tab)">
            {{ tab }}
          </a>
        </li>
      </ul>

      <div class="tab-content mt-3">
        <div v-if="activeTab === 'Overview'">
          <Overview :candidate="candidate" :faculty_name="faculty_name" :sub_speciality="sub_speciality" />
        </div>
        <div v-if="activeTab === 'Biodata'">
          <Biodata
            v-if="candidate && candidate.biodata"
            :faculty_name="faculty_name"
            :sub_speciality="sub_speciality"
            :biodata="candidate.biodata"
            :candidate_form="candidate"
            @init-update="handleUpdate"
            @form-submitted="handleFormSubmitted"
          />
        </div>
        <div v-if="activeTab === 'Application'">
          <Application v-if="candidate && candidate.applications" :candidate="candidate" />
        </div>
        <div v-if="activeTab === 'Documents'">
          <Documents v-if="candidate && candidate.id" :candidate="candidate" :doc_fields="doc_fields" />
        </div>
        <div v-if="activeTab === 'Results'">
          <Results v-if="candidate && candidate.results" :candidate="candidate" />
        </div>
        <div v-if="formSubmitted" class="alert alert-success mt-3">
          Form submitted successfully!
        </div>
      </div>
    </div>
  `,
};

createApp(App).mount('#app');
